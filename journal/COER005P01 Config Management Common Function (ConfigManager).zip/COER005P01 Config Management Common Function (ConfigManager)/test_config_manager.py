import json
import os
import pytest # this is the pytest version of the unit test
from pathlib import Path
from datetime import datetime
# Import modules directly from same folder (no package structure)
from ConfigManager import ConfigManager
from global_store import GLOBAL_DYNAMIC_STORE
# ------------------------------------------------------------
# Pytest Fixtures
# ------------------------------------------------------------
@pytest.fixture
def temp_config_dir(tmp_path, monkeypatch):
    """
    Creates a temporary config directory and sets ERP_conf_PATH
    to point to it for all tests.
    """
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    monkeypatch.setenv("ERP_conf_PATH", str(config_dir))
    # Create required config files
    (config_dir / "CommonConfig.json").write_text(json.dumps({
        "timeout": "300",
        "mode": "FULL"
    }))
    (config_dir / "ERPInboundParameter.json").write_text(json.dumps({
        "param1": "value1"
    }))
    (config_dir / "BASEDATE.csv").write_text(
        "key,value\nBASEDATE_,20260320\n"
    )
    (config_dir / "COMF001.csv").write_text(
        "external_id,internal_id\nabc,123\n"
    )
    (config_dir / "DYNAMIC_JOB001.csv").write_text(
        "key,value\nlast_run,20260201\n"
    )
    yield config_dir
    GLOBAL_DYNAMIC_STORE.clear()
@pytest.fixture
def manager():
    """Provides a fresh ConfigManager instance."""
    return ConfigManager()
# ------------------------------------------------------------
# Test Cases
# ------------------------------------------------------------
def test_normal_retrieval(temp_config_dir, manager):
    request = {
        "caller": "InboundProcessor",
        "job_id": "JOB001",
        "name": "CommonConfig",
        "key": "timeout",
        "format": "string",
        "requires_id_conversion": False,
        "dynamic": False,
        "requires_date_processing": False
    }
    result = manager.get_config(request)
    assert result["return_code"] == 0
    assert result["value"] == "300"
def test_missing_config_file(temp_config_dir, manager):
    request = {
        "caller": "InboundProcessor",
        "job_id": "JOB001",
        "name": "NonExistentFile",
        "key": "unknown",
        "format": "string"
    }
    result = manager.get_config(request)
    assert result["return_code"] in (1, 8)
def test_missing_key(temp_config_dir, manager):
    request = {
        "caller": "InboundProcessor",
        "job_id": "JOB001",
        "name": "CommonConfig",
        "key": "missing_key",
        "format": "string"
    }
    result = manager.get_config(request)
    assert result["return_code"] == 1   # key not found
def test_internal_id_conversion(temp_config_dir, manager):
    # Override value so mode="abc"
    (temp_config_dir / "CommonConfig.json").write_text(json.dumps({
        "mode": "abc"
    }))
    request = {
        "caller": "InboundProcessor",
        "job_id": "JOB001",
        "name": "CommonConfig",
        "key": "mode",
        "format": "string",
        "requires_id_conversion": True
    }
    result = manager.get_config(request)
    assert result["return_code"] == 0
    assert result["value"] == "123"
def test_date_parameter(temp_config_dir, manager):
    # Override config so timeout uses BASEDATE_
    (temp_config_dir / "CommonConfig.json").write_text(json.dumps({
        "timeout": "BASEDATE_"
    }))
    request = {
        "caller": "InboundProcessor",
        "job_id": "JOB001",
        "name": "CommonConfig",
        "key": "timeout",
        "format": "string",
        "requires_date_processing": True
    }
    result = manager.get_config(request)
    assert result["return_code"] == 0
    assert result["value"] == "20260320"
def test_dynamic_parameter(temp_config_dir, manager):
    request = {
        "caller": "InboundProcessor",
        "job_id": "JOB001",
        "name": "DYNAMIC_JOB001",
        "key": "last_run",
        "format": "string",
        "dynamic": True
    }
    result = manager.get_config(request)
    assert result["return_code"] == 0
    assert "dynamic_parameter" in result["value"]
def test_global_storage_for_inbound(temp_config_dir, manager):
    request = {
        "caller": "InboundProcessor",
        "job_id": "JOB001",
        "name": "CommonConfig",
        "key": "timeout",
        "format": "string",
    }
    manager.get_config(request)
    assert GLOBAL_DYNAMIC_STORE["InboundProcessor"]["JOB001"]["timeout"] == "300"
def test_authmanager_temp_storage(temp_config_dir, manager):
    request = {
        "caller": "AuthManager",
        "job_id": "JOB001",
        "name": "CommonConfig",
        "key": "timeout",
        "format": "string",
    }
    result = manager.get_config(request)
    assert result["return_code"] == 0
    assert hasattr(manager, "temp_auth_value")
    assert manager.temp_auth_value == "300"