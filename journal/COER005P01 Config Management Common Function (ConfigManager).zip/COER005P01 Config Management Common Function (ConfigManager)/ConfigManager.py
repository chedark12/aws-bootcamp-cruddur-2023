# ============================================================
# ConfigManager.py  (PART 4-A)
# Main implementation of the Config Management Common Function
# Steps covered in this part:
#   (1) Variables Initialization
#       1.1 Initialize all local variables
#       1.2 Initialize all environment variables
# ============================================================
import os
from pathlib import Path
from datetime import datetime
from constants import (
    VALID_CALLERS,
    VALID_CONFIG_FILES,
    RETURN_NORMAL,
    RETURN_WARNING,
    RETURN_ABNORMAL,
    MESSAGE_COMM0001I,
    MESSAGE_COMM0016E,
    MESSAGE_COMM0017E,
    MESSAGE_COMM0018E,
    MESSAGE_COMM0019E,
)
from helpers import (
    write_log,
    get_timestamp,
    load_json_file,
    load_csv_keyvalue,
    build_exception_response,
    build_success_response,
    convert_internal_id,
    load_dynamic_parameter_file,
    update_dynamic_parameter_file,
    load_date_parameter_mapping,
    replace_date_template,
)
from global_store import (
    save_dynamic_value,
    delete_dynamic_job_values,
    get_dynamic_value,
)

class ConfigManager:
    # ------------------------------------------------------------
    # (1) VARIABLES INITIALIZATION
    # ------------------------------------------------------------
    def __init__(self):
        # ------------------------------------------------------------
        # (1.1) Initialize all local variables to be used in this function
        # ------------------------------------------------------------
        self.request = None
        self.caller = ""
        self.job_id = ""
        self.config_name = ""
        self.key = ""
        self.format_type = ""
        self.requires_id = False
        self.requires_dynamic = False
        self.requires_date = False
        self.config_base_path = None
        self.log_file_path = None
        # ------------------------------------------------------------
        # (1.2) Initialize environment variables
        #       Parameter Name: ERP_conf_PATH
        #       Contents: "/app/<environment>/config files/"
        # ------------------------------------------------------------
        self.ERP_conf_PATH = os.environ.get("ERP_conf_PATH")
        # Validate ERP_conf_PATH early
        if not self.ERP_conf_PATH:
            # If not set, default to "config/"
            self.ERP_conf_PATH = "config/"
        # Ensure directory object
        self.ERP_conf_PATH = Path(self.ERP_conf_PATH)
        # Prepare directory structure
        self.ERP_conf_PATH.mkdir(parents=True, exist_ok=True)

# ============================================================
# ConfigManager.py  (PART 4-B)
# Steps covered in this part:
#   (2) Start Log
#   (3) Identify Caller of Config Manager
# ============================================================
    # ------------------------------------------------------------
    # Main entry function
    # ------------------------------------------------------------
    def get_config(self, request: dict):
        # Store request
        self.request = request
        # Extract basic request parameters
        self.caller = request.get("caller", "")
        self.job_id = request.get("job_id", "NOJOBID")
        self.config_name = request.get("name", "")
        self.key = request.get("key", "")
        self.format_type = request.get("format", "")
        self.requires_id = request.get("requires_id_conversion", False)
        self.requires_dynamic = request.get("dynamic", False)
        self.requires_date = request.get("requires_date_processing", False)
        # ------------------------------------------------------------
        # (2) START LOG
        # ------------------------------------------------------------
        # Create MST log filename: {JOBID}_YYYYMMDD_HI24MISS.MSS.log
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"{self.job_id}_{timestamp}.MSS.log"
        log_dir = Path("logs")
        log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file_path = log_dir / log_filename
        # (2.1) Job Argument Settings - Output a log of the start
        # Parameter Name: message_id = COMM0001I
        # log_level = Info
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            f"Start parameter acquisition. Caller={self.caller}, JobID={self.job_id}"
        )
        # ------------------------------------------------------------
        # (3) IDENTIFY THE CALLER OF CONFIG MANAGER
        # ------------------------------------------------------------
        # (3.1) Determine the process that called the Config Manager
        #       and assign the allowed list of config files
        if self.caller not in VALID_CALLERS:
            # Invalid caller → return 8, COMM0016E
            message = f"Invalid caller '{self.caller}'. Caller not authorized."
            return {
                "return_code": RETURN_ABNORMAL,
                "value": None,
                "message": message,
                "exception_content": f"InvalidCaller:{self.caller}",
                "log_file": str(self.log_file_path)
            }
        # Valid caller → Log success
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            f"Caller '{self.caller}' validated successfully."
        )

# ============================================================
# ConfigManager.py (PART 4-C)
# Steps covered in this part:
#   (4) Extract Target Configuration File(s)
#       (4.1) List of possible files (documented)
#       (4.2.1) Validate file existence
#       (4.2.2) Validate JSON format
#       (4.2.3) Validate requested key exists
# ============================================================
        # ------------------------------------------------------------
        # (4) EXTRACT TARGET CONFIGURATION FILE(S)
        # ------------------------------------------------------------
        # ------------------------------------------------------------
        # (4.1) List of all possible configuration files
        # (Documented via VALID_CONFIG_FILES in constants.py)
        # ------------------------------------------------------------
        # Files:
        #   - CommonConfig.json
        #   - ESSJobParameter.json
        #   - ERPInboundParameter.json
        #   - ERPOutboundParameter.json
        #   - ConfigOauth.json
        #   - COMF001.csv
        #   - S3Config.json
        #   - FileConfig.json
        #   - DYNAMIC_<JOBID>.csv
        #   - BASEDATE.csv
        #   - ErpMessage.json
        #   - ConfigOCILog.json
        # ------------------------------------------------------------
        # Determine actual config file path
        if self.config_name.startswith("DYNAMIC_"):
            # Dynamic file naming rule
            config_filename = f"DYNAMIC_{self.job_id}.csv"
        else:
            config_filename = VALID_CONFIG_FILES.get(self.config_name)
        config_file_path = self.ERP_conf_PATH / config_filename
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            f"(4) Attempting to load configuration file: {config_file_path}"
        )
        # ------------------------------------------------------------
        # (4.2.1) Verify configuration file exists before read.
        # ------------------------------------------------------------
        if not config_file_path.exists():
            # (4.2.1.2) File not found → return_code 1 + log COMM0016E
            write_log(
                self.log_file_path,
                MESSAGE_COMM0016E,
                "Error",
                f"Configuration file not found: {config_file_path}"
            )
            return {
                "return_code": RETURN_WARNING,
                "value": None,
                "message": f"Configuration file missing: {config_filename}",
                "exception_content": "FileNotFound",
                "log_file": str(self.log_file_path),
            }
        # (4.2.1.1) File exists → continue
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            f"(4.2.1.1) File exists → Proceeding"
        )
        # ------------------------------------------------------------
        # (4.2.2) Verify configuration file format is valid (JSON only)
        # ------------------------------------------------------------
        file_ext = config_file_path.suffix.lower()
        try:
            if file_ext == ".json":
                config_data = load_json_file(config_file_path)
            elif file_ext == ".csv":
                config_data = load_csv_keyvalue(config_file_path)
            else:
                # Safety fallback: unsupported format should not happen
                config_data = None
        except Exception as e:
            # (4.2.2.2) JSON parsing failed → COMM0017E
            write_log(
                self.log_file_path,
                MESSAGE_COMM0017E,
                "Error",
                f"JSON parsing error in file {config_filename}: {str(e)}"
            )
            return {
                "return_code": RETURN_WARNING,
                "value": None,
                "message": f"Invalid JSON in {config_filename}",
                "exception_content": str(e),
                "log_file": str(self.log_file_path),
            }
        # (4.2.2.1) Valid JSON/CSV → continue
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            f"(4.2.2.1) Configuration file format OK: {config_filename}"
        )
        # ------------------------------------------------------------
        # (4.2.3) Verify requested key exists in configuration file
        # ------------------------------------------------------------
        if self.key not in config_data:
            # (4.2.3.2) Key missing → COMM0018E
            write_log(
                self.log_file_path,
                MESSAGE_COMM0018E,
                "Error",
                f"Requested key '{self.key}' not found in file {config_filename}"
            )
            return {
                "return_code": RETURN_WARNING,
                "value": None,
                "message": f"Key '{self.key}' missing in configuration file.",
                "exception_content": "KeyNotFound",
                "log_file": str(self.log_file_path),
            }
        # (4.2.3.1) Key found → extract value
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            f"(4.2.3.1) Key '{self.key}' found. Extracting value..."
        )
        # Save extracted value
        extracted_value = config_data[self.key]

# ============================================================
# ConfigManager.py (PART 4-D)
# Steps covered in this part:
#   (4.3) Save value depending on caller process
#   (5) Parameter Type Processing
#   (5.1) Supported types
#   (5.2) Internal ID Conversion validation rules
#   (5.3) Dynamic Parameter validation rules
#   (5.4) Date Parameter Processing validation rules
#   (5.5) Normal End return
# ============================================================
        # ------------------------------------------------------------
        # (4.3) SAVE OBTAINED VALUES DEPENDING ON CALLER PROCESS
        # ------------------------------------------------------------
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            "(4.3) Determining storage category for caller..."
        )
        # 4.3.1 Inbound/Outbound/ESSJobExecuteProcessor → save on dynamic global variable
        if self.caller in ("InboundProcessor", "OutboundProcessor", "ESSJobExecuteProcessor"):
            save_dynamic_value(self.caller, self.job_id, self.key, extracted_value)
            write_log(
                self.log_file_path,
                MESSAGE_COMM0001I,
                "Info",
                f"Saved value to GLOBAL_DYNAMIC_STORE[{self.caller}][{self.job_id}]"
            )
        # 4.3.2 AuthManager → temporary variable only
        elif self.caller == "AuthManager":
            self.temp_auth_value = extracted_value
            write_log(
                self.log_file_path,
                MESSAGE_COMM0001I,
                "Info",
                "Stored AuthManager temporary value."
            )
        # 4.3.4 FileOperationService / S3OperationService → dynamic global
        elif self.caller in ("FileOperationService", "S3OperationService"):
            save_dynamic_value(self.caller, self.job_id, self.key, extracted_value)
            write_log(
                self.log_file_path,
                MESSAGE_COMM0001I,
                "Info",
                f"Saved value to GLOBAL_DYNAMIC_STORE[{self.caller}][{self.job_id}]"
            )
        # ------------------------------------------------------------
        # (5) START PROCESSING FOR DIFFERENT PARAMETER TYPES
        # ------------------------------------------------------------
        # (5.1) Supported parameter types (documentation only)
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            "(5.1) Checking parameter type and required processing..."
        )
        final_value = extracted_value
        # ------------------------------------------------------------
        # (5.2) INTERNAL ID CONVERSION
        # ------------------------------------------------------------
        if self.requires_id:
            write_log(
                self.log_file_path,
                MESSAGE_COMM0001I,
                "Info",
                "(5.2) Internal ID Conversion required."
            )
            comf_file_path = self.ERP_conf_PATH / VALID_CONFIG_FILES["COMF001"]
            # (5.2.1) Check internal ID conversion file existence
            if not comf_file_path.exists():
                write_log(
                    self.log_file_path,
                    MESSAGE_COMM0019E,
                    "Error",
                    "COMF001.csv not found but internal ID conversion was required."
                )
                return {
                    "return_code": RETURN_WARNING,
                    "value": None,
                    "message": "Internal ID file missing.",
                    "exception_content": "FileNotFound",
                    "log_file": str(self.log_file_path)
                }
            # (5.2.2) Attempt internal ID conversion
            internal_value = convert_internal_id(comf_file_path, final_value)
            if internal_value is None:
                write_log(
                    self.log_file_path,
                    MESSAGE_COMM0018E,
                    "Error",
                    f"No internal ID mapping found for '{final_value}'."
                )
                return {
                    "return_code": RETURN_WARNING,
                    "value": None,
                    "message": "Internal ID mapping missing.",
                    "exception_content": "KeyNotFound",
                    "log_file": str(self.log_file_path)
                }
            final_value = internal_value
        # ------------------------------------------------------------
        # (5.3) DYNAMIC PARAMETER PROCESSING
        # ------------------------------------------------------------
        if self.requires_dynamic:
            write_log(
                self.log_file_path,
                MESSAGE_COMM0001I,
                "Info",
                "(5.3) Dynamic Parameter Processing required."
            )
            dynamic_file = self.ERP_conf_PATH / f"DYNAMIC_{self.job_id}.csv"
            # (5.3.1) Check existence of dynamic parameter file
            if not dynamic_file.exists():
                write_log(
                    self.log_file_path,
                    MESSAGE_COMM0019E,
                    "Error",
                    f"Dynamic parameter file DYNAMIC_{self.job_id}.csv missing."
                )
                return {
                    "return_code": RETURN_WARNING,
                    "value": None,
                    "message": "Dynamic parameter file not found.",
                    "exception_content": "FileNotFound",
                    "log_file": str(self.log_file_path)
                }
            # Load dynamic parameter file
            dynamic_map = load_dynamic_parameter_file(dynamic_file)
            # (5.3.2) Key must exist inside DYNAMIC_<JOBID>.csv
            if self.key not in dynamic_map:
                write_log(
                    self.log_file_path,
                    MESSAGE_COMM0018E,
                    "Error",
                    f"Dynamic parameter definition missing for key '{self.key}'."
                )
                return {
                    "return_code": RETURN_WARNING,
                    "value": None,
                    "message": "Dynamic parameter key missing.",
                    "exception_content": "KeyNotFound",
                    "log_file": str(self.log_file_path)
                }
            final_value = dynamic_map[self.key]
            # Update previous + current exec date
            prev_exec_date = dynamic_map.get("current_execution_date", "00000000")
            update_dynamic_parameter_file(dynamic_file, prev_exec_date)
        # ------------------------------------------------------------
        # (5.4) DATE PARAMETER PROCESSING
        # ------------------------------------------------------------
        if self.requires_date:
            write_log(
                self.log_file_path,
                MESSAGE_COMM0001I,
                "Info",
                "(5.4) Date Parameter Processing required."
            )
            base_date_path = self.ERP_conf_PATH / VALID_CONFIG_FILES["BASEDATE"]
            # (5.4.1) Check BASEDATE.csv existence
            if not base_date_path.exists():
                write_log(
                    self.log_file_path,
                    MESSAGE_COMM0019E,
                    "Error",
                    "BASEDATE.csv not found but date parameter processing required."
                )
                return {
                    "return_code": RETURN_WARNING,
                    "value": None,
                    "message": "BASEDATE.csv missing.",
                    "exception_content": "FileNotFound",
                    "log_file": str(self.log_file_path)
                }
            # (5.4.2) Load BASEDATE.csv and verify key
            date_map = load_date_parameter_mapping(base_date_path)
            if self.key not in date_map:
                write_log(
                    self.log_file_path,
                    MESSAGE_COMM0018E,
                    "Error",
                    f"Date parameter definition missing for key '{self.key}'."
                )
                return {
                    "return_code": RETURN_WARNING,
                    "value": None,
                    "message": "Date parameter definition missing.",
                    "exception_content": "KeyNotFound",
                    "log_file": str(self.log_file_path)
                }
            # Replace template (BASEDATE_ → actual date)
            actual_date = date_map[self.key]
            final_value = replace_date_template(final_value, actual_date)
        # ------------------------------------------------------------
        # (5.5) NORMAL END — RETURN CODE 0
        # ------------------------------------------------------------
        write_log(
            self.log_file_path,
            MESSAGE_COMM0001I,
            "Info",
            "(5.5) ConfigManager processing successful."
        )
        return {
            "return_code": RETURN_NORMAL,
            "value": final_value,
            "message": "Normal End",
            "log_file": str(self.log_file_path)
        }
