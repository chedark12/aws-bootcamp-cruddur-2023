# ============================================================
# global_store.py
# Contains global dynamic storage for ConfigManager
# Structure:
#   GLOBAL_DYNAMIC_STORE[caller][job_id][key] = value
# ============================================================
# Global dynamic configuration storage
GLOBAL_DYNAMIC_STORE = {}
def init_caller_store(caller: str):
    """
    Ensures the caller-level dictionary exists.
    """
    if caller not in GLOBAL_DYNAMIC_STORE:
        GLOBAL_DYNAMIC_STORE[caller] = {}
def init_job_store(caller: str, job_id: str):
    """
    Ensures the job_id-level dictionary exists for a caller.
    """
    init_caller_store(caller)
    if job_id not in GLOBAL_DYNAMIC_STORE[caller]:
        GLOBAL_DYNAMIC_STORE[caller][job_id] = {}
def save_dynamic_value(caller: str, job_id: str, key: str, value):
    """
    Saves a dynamic config value inside the global store.
    Structure:
        GLOBAL_DYNAMIC_STORE[caller][job_id][key] = value
    """
    init_job_store(caller, job_id)
    GLOBAL_DYNAMIC_STORE[caller][job_id][key] = value
def get_dynamic_value(caller: str, job_id: str, key: str):
    """
    Retrieves a dynamic value if it exists, otherwise returns None.
    """
    try:
        return GLOBAL_DYNAMIC_STORE[caller][job_id].get(key)
    except KeyError:
        return None
def delete_dynamic_job_values(caller: str, job_id: str):
    """
    Deletes ALL dynamic values for a specific caller + job_id.
    Used after AuthManager finishes using temporary parameters.
    """
    if (
        caller in GLOBAL_DYNAMIC_STORE
        and job_id in GLOBAL_DYNAMIC_STORE[caller]
    ):
        del GLOBAL_DYNAMIC_STORE[caller][job_id]
def delete_dynamic_key(caller: str, job_id: str, key: str):
    """
    Deletes only a single key inside the job_id dictionary.
    """
    try:
        del GLOBAL_DYNAMIC_STORE[caller][job_id][key]
    except KeyError:
        pass