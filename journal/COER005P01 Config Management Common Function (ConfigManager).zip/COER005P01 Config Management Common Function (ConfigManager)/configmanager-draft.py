import json
import csv
import logging
from datetime import datetime
from pathlib import Path
class ConfigNotFoundError(Exception):
    pass
class DateParameterError(Exception):
    pass
class ConfigManager:
    # Return codes
    RETURN_NORMAL = 0
    RETURN_WARNING = 1
    RETURN_ABNORMAL = 8
    # Valid config file sources
    VALID_CONFIG_FILES = {
        "CommonConfig": "CommonConfig.json",
        "ESSJobParameter": "ESSJobParameter.json",
        "ERPInboundParameter": "ERPInboundParameter.json",
        "ERPOutboundParameter": "ERPOutboundParameter.json",
        "ConfigOauth": "ConfigOauth.json",
        "COMF001": "COMF001.csv",
        "S3Config": "S3Config.json",
        "FileConfig": "FileConfig.json",
        "BASEDATE": "BASEDATE.csv",
        "ErpMessage": "ErpMessage.json",
        "ConfigOCILog": "ConfigOCILog.json"
    }
    # ----------------------------------------------------------------------
    # Allowed calling processes
    # ----------------------------------------------------------------------
    VALID_CALLERS = {
        "InboundProcessor",
        "OutboundProcessor",
        "ESSJobExecuteProcessor",
        "AuthManager",
        "S3OperationService",
        "FileOperationService"
    }
    def __init__(self, config_dir="config", output_dir="logs"):
        self.config_dir = Path(config_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(level=logging.INFO)
    def get_config(self, request):
        """
        This version validates callers and outputs a log file:
        {JOBID}_YYYYMMDD_HI24MISS.MSS.log
        """
        # ----------------------------------------------------------
        # 1. Start of Processing
        # ----------------------------------------------------------
        caller = request.get("caller", "")
        job_id = request.get("job_id", "NOJOBID")
        config_name = request.get("name")
        key = request.get("key")
        # Build output log filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"{job_id}_{timestamp}.MSS.log"
        log_path = self.output_dir / log_filename
        def write_log(msg):
            with open(log_path, "a") as f:
                f.write(msg + "\n")
        write_log("=== START CONFIG PROCESSING ===")
        write_log(f"JOBID={job_id}")
        write_log(f"Caller={caller}")
        # ----------------------------------------------------------
        # Validate the caller
        # ----------------------------------------------------------
        if caller not in self.VALID_CALLERS:
            message = f"Invalid caller '{caller}' is not authorized to use Config Manager."
            write_log(message)
            return self._return(self.RETURN_ABNORMAL, None, message, log_path)
        write_log("Caller validated.")
        # ----------------------------------------------------------
        # 2. Determine config file for extraction
        # ----------------------------------------------------------
        if config_name not in self.VALID_CONFIG_FILES and not config_name.startswith("DYNAMIC_"):
            message = f"Unknown config source: {config_name}"
            write_log(message)
            return self._return(self.RETURN_ABNORMAL, None, message, log_path)
        if config_name.startswith("DYNAMIC_"):
            config_file = f"DYNAMIC_{job_id}.csv"
        else:
            config_file = self.VALID_CONFIG_FILES[config_name]
        config_source = self.config_dir / config_file
        write_log(f"Assigned config file: {config_source}")
        # ----------------------------------------------------------
        # 3. Extract the target Configuration File
        # ----------------------------------------------------------
        if not config_source.exists():
            message = f"Config file not found: {config_source}"
            write_log(message)
            return self._return(self.RETURN_ABNORMAL, None, message, log_path)
        if config_source.suffix == ".csv":
            value_map = self._load_csv_as_dict(config_source)
        else:
            try:
                with open(config_source, "r") as f:
                    value_map = json.load(f)
            except json.JSONDecodeError:
                message = f"Invalid JSON format: {config_source}"
                write_log(message)
                return self._return(self.RETURN_ABNORMAL, None, message, log_path)
        if key not in value_map:
            message = f"Key '{key}' not found in {config_file}"
            write_log(message)
            return self._return(self.RETURN_ABNORMAL, None, message, log_path)
        value = value_map[key]
        write_log(f"Extracted value for key '{key}': {value}")
        # ----------------------------------------------------------
        # 4. Validate and determine parameter type
        # ----------------------------------------------------------
        # ID conversion (COMF001.csv)
        if request.get("requires_id_conversion"):
            try:
                value = self._convert_internal_id(value)
                write_log(f"ID Conversion result: {value}")
            except ConfigNotFoundError as e:
                write_log(str(e))
                return self._return(self.RETURN_ABNORMAL, None, str(e), log_path)
        # Dynamic parameter
        if request.get("dynamic"):
            write_log("Dynamic parameter definition returned.")
            return self._return(
                self.RETURN_NORMAL,
                {"dynamic_parameter": True, "name": config_name, "key": key, "definition": value},
                "Dynamic parameter definition returned.",
                log_path
            )
        # Date parameter processing (BASEDATE.csv)
        if request.get("requires_date_processing"):
            try:
                value = self._process_date_parameter(value)
                write_log(f"Date parameter processed result: {value}")
            except DateParameterError as e:
                write_log(str(e))
                return self._return(self.RETURN_ABNORMAL, None, str(e), log_path)
        # Formatting
        try:
            formatted_value = self._format_value(value, request.get("format"))
            write_log(f"Formatted value: {formatted_value}")
        except Exception:
            message = "Format conversion failed. Returning raw value."
            write_log(message)
            return self._return(self.RETURN_WARNING, value, message, log_path)
        # Normal End
        write_log("Normal End")
        return self._return(self.RETURN_NORMAL, formatted_value, "Normal End", log_path)
    # ----------------------------------------------------------------------
    # Helper functions
    # ----------------------------------------------------------------------
    def _load_csv_as_dict(self, file_path):
        result = {}
        with open(file_path, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                key = row.get("key")
                value = row.get("value")
                if key:
                    result[key] = value
        return result
    def _convert_internal_id(self, value):
        comf_file = self.config_dir / self.VALID_CONFIG_FILES["COMF001"]
        if not comf_file.exists():
            raise ConfigNotFoundError("COMF001.csv missing.")
        with open(comf_file, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row.get("external_id") == str(value):
                    return row.get("internal_id")
        raise ConfigNotFoundError(f"No internal ID mapping for: {value}")
    def _process_date_parameter(self, value):
        base_date_file = self.config_dir / self.VALID_CONFIG_FILES["BASEDATE"]
        if not base_date_file.exists():
            raise DateParameterError("BASEDATE.csv missing.")
        with open(base_date_file, "r", newline="") as f:
            reader = csv.DictReader(f)
            mapping = {row["keyword"]: row["format"] for row in reader}
        if value not in mapping:
            raise DateParameterError(f"Date parameter '{value}' missing in BASEDATE.csv")
        return datetime.now().strftime(mapping[value])
    def _format_value(self, value, format_type):
        if format_type == "string": return str(value)
        if format_type == "int": return int(value)
        if format_type == "float": return float(value)
        if format_type == "dict" and isinstance(value, dict): return value
        return value
    def _return(self, code, value, message, log_path):
        return {
            "return_code": code,
            "value": value,
            "message": message,
            "log_file": str(log_path)
        }
# ----------------------------------------------------------
# Example usage
# ----------------------------------------------------------
if __name__ == "__main__":
    manager = ConfigManager()
    req = {
        "caller": "InboundProcessor",  # Must be in VALID_CALLERS
        "job_id": "JOB0001",
        "name": "CommonConfig",
        "key": "timeout",
        "format": "int",
        "dynamic": False,
        "requires_id_conversion": False,
        "requires_date_processing": False
    }
    print(manager.get_config(req))