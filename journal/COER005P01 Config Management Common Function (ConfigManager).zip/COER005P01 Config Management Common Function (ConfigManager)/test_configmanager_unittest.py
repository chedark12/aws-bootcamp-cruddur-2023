import unittest
import os
import tempfile
import json
from pathlib import Path
from datetime import datetime
from ConfigManager import ConfigManager
from global_store import GLOBAL_DYNAMIC_STORE
class TestConfigManager(unittest.TestCase):
    def setUp(self):
        # Temporary directory for config files
        self.temp_dir = tempfile.TemporaryDirectory()
        os.environ["ERP_conf_PATH"] = self.temp_dir.name
        base = Path(self.temp_dir.name)
        # Sample dataset – CommonConfig.json
        (base / "CommonConfig.json").write_text(json.dumps({
            "timeout": "300",
            "mode": "FULL",
            "date_param": "BASEDATE_"
        }))
        # Sample dataset – ERPInboundParameter.json
        (base / "ERPInboundParameter.json").write_text(json.dumps({
            "param1": "value1"
        }))
        # COMF001.csv for internal ID conversion
        (base / "COMF001.csv").write_text(
            "external_id,internal_id\nabc,123\n"
        )
        # BASEDATE.csv for date processing
        (base / "BASEDATE.csv").write_text(
            "key,value\nBASEDATE_,20260320\n"
        )
        # Dynamic parameter file
        (base / "DYNAMIC_JOB001.csv").write_text(
            "key,value\nlast_run,20250101\n"
        )
        self.manager = ConfigManager()
    def tearDown(self):
        self.temp_dir.cleanup()
        GLOBAL_DYNAMIC_STORE.clear()
    # ------------------------------------------------------------
    # Test: Normal Case
    # ------------------------------------------------------------
    def test_normal_retrieval(self):
        req = {
            "caller": "InboundProcessor",
            "job_id": "JOB001",
            "name": "CommonConfig",
            "key": "timeout",
            "format": "string"
        }
        result = self.manager.get_config(req)
        self.assertEqual(result["return_code"], 0)
        self.assertEqual(result["value"], "300")
    # ------------------------------------------------------------
    # Test: Missing config file → abnormal end
    # ------------------------------------------------------------
    def test_missing_config_file(self):
        req = {
            "caller": "InboundProcessor",
            "job_id": "JOB001",
            "name": "FileNotHere",
            "key": "timeout",
            "format": "string"
        }
        result = self.manager.get_config(req)
        self.assertIn(result["return_code"], (1, 8))
    # ------------------------------------------------------------
    # Test: Missing key → warning end
    # ------------------------------------------------------------
    def test_missing_key(self):
        req = {
            "caller": "InboundProcessor",
            "job_id": "JOB001",
            "name": "CommonConfig",
            "key": "notfound",
            "format": "string"
        }
        result = self.manager.get_config(req)
        self.assertEqual(result["return_code"], 1)
    # ------------------------------------------------------------
    # Test: Internal ID Conversion
    # ------------------------------------------------------------
    def test_internal_id_conversion(self):
        base = Path(self.temp_dir.name)
        (base / "CommonConfig.json").write_text(json.dumps({
            "idvalue": "abc"
        }))
        req = {
            "caller": "InboundProcessor",
            "job_id": "JOB001",
            "name": "CommonConfig",
            "key": "idvalue",
            "format": "string",
            "requires_id_conversion": True
        }
        result = self.manager.get_config(req)
        self.assertEqual(result["return_code"], 0)
        self.assertEqual(result["value"], "123")
    # ------------------------------------------------------------
    # Test: Date parameter
    # ------------------------------------------------------------
    def test_date_param(self):
        req = {
            "caller": "InboundProcessor",
            "job_id": "JOB001",
            "name": "CommonConfig",
            "key": "date_param",
            "format": "string",
            "requires_date_processing": True
        }
        result = self.manager.get_config(req)
        self.assertEqual(result["return_code"], 0)
        self.assertEqual(result["value"], "20260320")
    # ------------------------------------------------------------
    # Test: Dynamic parameter
    # ------------------------------------------------------------
    def test_dynamic_parameter(self):
        req = {
            "caller": "InboundProcessor",
            "job_id": "JOB001",
            "name": "DYNAMIC_JOB001",
            "key": "last_run",
            "format": "string",
            "dynamic": True
        }
        result = self.manager.get_config(req)
        self.assertEqual(result["return_code"], 0)
        self.assertIn("dynamic_parameter", result["value"])
    # ------------------------------------------------------------
    # Test: Global storage (InboundProcessor)
    # ------------------------------------------------------------
    def test_global_store(self):
        req = {
            "caller": "InboundProcessor",
            "job_id": "JOB001",
            "name": "CommonConfig",
            "key": "timeout",
            "format": "string"
        }
        _ = self.manager.get_config(req)
        self.assertEqual(
            GLOBAL_DYNAMIC_STORE["InboundProcessor"]["JOB001"]["timeout"],
            "300"
        )
    # ------------------------------------------------------------
    # Test: AuthManager – temporary storage only
    # ------------------------------------------------------------
    def test_authmanager_temp_storage(self):
        req = {
            "caller": "AuthManager",
            "job_id": "JOB001",
            "name": "CommonConfig",
            "key": "timeout",
            "format": "string"
        }
        result = self.manager.get_config(req)
        self.assertEqual(result["return_code"], 0)
        self.assertTrue(hasattr(self.manager, "temp_auth_value"))
        self.assertEqual(self.manager.temp_auth_value, "300")
if __name__ == "__main__":
    unittest.main()